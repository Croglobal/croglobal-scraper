# Croglobal RSS Scraper

Besplatni pozadinski scraper za Croglobal `/objava` — periodički (svakih 5 min)
dohvaća RSS feedove hrvatskih portala i sprema naslov, link i točno vrijeme
objave u `data/latest.json`, bez potrebe za VPS-om ili plaćenim serverom.

## Postavljanje (jednom)

1. Napravi **novi javni (public) GitHub repozitorij**, npr. `croglobal-scraper`.
   Mora biti public da GitHub Actions bude potpuno besplatan bez limita minuta.
2. Ubaci sve datoteke iz ovog paketa u taj repo (zadrži strukturu foldera,
   pogotovo `.github/workflows/scrape.yml`).
3. Commitaj i pushaj na `main` granu.
4. Idi na tab **Actions** u repozitoriju — workflow "Croglobal RSS Scraper" bi
   se trebao pojaviti i automatski početi raditi po cron rasporedu (svakih 5 min).
5. Za prvi test, klikni **Run workflow** ručno (workflow_dispatch) da odmah
   provjeriš radi li sve kako treba, umjesto da čekaš 5 minuta.

## Kako Claude čita rezultate

Nakon što je repo aktivan, podaci su dostupni na:

```
https://raw.githubusercontent.com/<tvoj-username>/<repo-ime>/main/data/latest.json
```

Taj URL Claude može dohvatiti direktno (`web_fetch`) na početku `/objava` — bez
ikakvog uživo Chrome browsinga za portale koji su na ovoj listi feedova.

## Dodavanje/uklanjanje portala

Uredi listu `FEEDS` na vrhu `scraper.py` — svaki unos treba `source` (ime za
prikaz) i `url` (RSS feed adresa). Nakon commita, sljedeći pokreni run će
automatski koristiti novu listu.

## Napomene

- Interval od 5 minuta je minimalni podržani cron interval na GitHub Actionsu.
  GitHub ne garantira apsolutnu točnost (može kasniti par minuta pod
  opterećenjem), ali za ovu svrhu je više nego dovoljno.
- `data/latest.json` čuva zadnjih 48h stavki (`RETENTION_HOURS` u `scraper.py`)
  da datoteka ne raste beskonačno — po potrebi promijeni tu vrijednost.
- Repo je javan pa je i sadržaj `data/latest.json` javno vidljiv — to su samo
  naslovi/linkovi/vremena javno dostupnih vijesti, ništa osjetljivo.
- Ako neki portal nema RSS ili ga blokira, skripta to bilježi kao `"error"` za
  taj feed umjesto da se sruši cijeli run.
